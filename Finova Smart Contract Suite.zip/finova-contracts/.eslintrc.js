module.exports = {
  root: true,
  env: {
    browser: true,
    es2022: true,
    node: true,
    jest: true,
    "react-native/react-native": true
  },
  extends: [
    "eslint:recommended",
    "@typescript-eslint/recommended",
    "@typescript-eslint/recommended-requiring-type-checking",
    "plugin:@typescript-eslint/strict",
    "plugin:react/recommended",
    "plugin:react-hooks/recommended",
    "plugin:react-native/all",
    "plugin:import/recommended",
    "plugin:import/typescript",
    "plugin:security/recommended",
    "plugin:sonarjs/recommended",
    "plugin:unicorn/recommended",
    "plugin:promise/recommended",
    "prettier"
  ],
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: "module",
    ecmaFeatures: {
      jsx: true,
      impliedStrict: true
    },
    project: ["./tsconfig.json", "./client/*/tsconfig.json", "./api/tsconfig.json"],
    tsconfigRootDir: __dirname
  },
  plugins: [
    "@typescript-eslint",
    "react",
    "react-hooks",
    "react-native",
    "import",
    "security",
    "sonarjs",
    "unicorn",
    "promise",
    "unused-imports",
    "sort-destructure-keys",
    "sort-keys-fix"
  ],
  settings: {
    react: {
      version: "detect"
    },
    "import/resolver": {
      typescript: {
        alwaysTryTypes: true,
        project: ["./tsconfig.json", "./client/*/tsconfig.json", "./api/tsconfig.json"]
      },
      node: {
        extensions: [".js", ".jsx", ".ts", ".tsx", ".json"]
      }
    },
    "import/parsers": {
      "@typescript-eslint/parser": [".ts", ".tsx"]
    }
  },
  rules: {
    // TypeScript specific rules
    "@typescript-eslint/no-unused-vars": ["error", { 
      argsIgnorePattern: "^_",
      varsIgnorePattern: "^_",
      caughtErrorsIgnorePattern: "^_"
    }],
    "@typescript-eslint/explicit-function-return-type": ["warn", {
      allowExpressions: true,
      allowTypedFunctionExpressions: true
    }],
    "@typescript-eslint/no-explicit-any": "error",
    "@typescript-eslint/no-unsafe-any": "error",
    "@typescript-eslint/no-unsafe-assignment": "error",
    "@typescript-eslint/no-unsafe-call": "error",
    "@typescript-eslint/no-unsafe-member-access": "error",
    "@typescript-eslint/no-unsafe-return": "error",
    "@typescript-eslint/prefer-readonly": "error",
    "@typescript-eslint/prefer-readonly-parameter-types": "off",
    "@typescript-eslint/strict-boolean-expressions": "error",
    "@typescript-eslint/switch-exhaustiveness-check": "error",
    "@typescript-eslint/consistent-type-definitions": ["error", "interface"],
    "@typescript-eslint/member-ordering": "error",
    "@typescript-eslint/no-confusing-void-expression": "error",
    "@typescript-eslint/no-duplicate-enum-values": "error",
    "@typescript-eslint/no-floating-promises": "error",
    "@typescript-eslint/no-for-in-array": "error",
    "@typescript-eslint/no-misused-promises": "error",
    "@typescript-eslint/promise-function-async": "error",
    "@typescript-eslint/require-array-sort-compare": "error",
    "@typescript-eslint/restrict-plus-operands": "error",

    // React specific rules
    "react/react-in-jsx-scope": "off",
    "react/prop-types": "off",
    "react/jsx-uses-react": "off",
    "react/jsx-uses-vars": "error",
    "react/jsx-no-undef": "error",
    "react/jsx-fragments": ["error", "syntax"],
    "react/jsx-boolean-value": ["error", "never"],
    "react/jsx-curly-brace-presence": ["error", { props: "never", children: "never" }],
    "react/jsx-sort-props": ["error", { 
      callbacksLast: true,
      shorthandFirst: true,
      ignoreCase: true,
      reservedFirst: true
    }],
    "react/self-closing-comp": "error",
    "react/void-dom-elements-no-children": "error",
    "react-hooks/rules-of-hooks": "error",
    "react-hooks/exhaustive-deps": "warn",

    // React Native specific rules
    "react-native/no-unused-styles": "error",
    "react-native/split-platform-components": "error",
    "react-native/no-inline-styles": "warn",
    "react-native/no-color-literals": "warn",
    "react-native/no-raw-text": "off",
    "react-native/sort-styles": "error",

    // Import rules
    "import/order": ["error", {
      "groups": [
        "builtin",
        "external",
        "internal",
        "parent",
        "sibling",
        "index",
        "object",
        "type"
      ],
      "newlines-between": "always",
      "alphabetize": {
        "order": "asc",
        "caseInsensitive": true
      },
      "pathGroups": [
        {
          "pattern": "@/**",
          "group": "internal",
          "position": "before"
        },
        {
          "pattern": "@finova/**",
          "group": "internal",
          "position": "before"
        }
      ],
      "pathGroupsExcludedImportTypes": ["builtin"]
    }],
    "import/no-unresolved": "error",
    "import/no-cycle": "error",
    "import/no-self-import": "error",
    "import/no-useless-path-segments": "error",
    "import/no-duplicates": "error",
    "import/first": "error",
    "import/newline-after-import": "error",
    "import/no-default-export": "off",
    "import/prefer-default-export": "off",

    // Security rules
    "security/detect-object-injection": "error",
    "security/detect-non-literal-regexp": "error",
    "security/detect-unsafe-regex": "error",
    "security/detect-buffer-noassert": "error",
    "security/detect-child-process": "error",
    "security/detect-disable-mustache-escape": "error",
    "security/detect-eval-with-expression": "error",
    "security/detect-no-csrf-before-method-override": "error",
    "security/detect-non-literal-fs-filename": "error",
    "security/detect-non-literal-require": "error",
    "security/detect-possible-timing-attacks": "error",
    "security/detect-pseudoRandomBytes": "error",

    // General code quality rules
    "no-console": ["warn", { allow: ["warn", "error", "info"] }],
    "no-debugger": "error",
    "no-alert": "error",
    "no-eval": "error",
    "no-implied-eval": "error",
    "no-new-func": "error",
    "no-script-url": "error",
    "no-proto": "error",
    "no-iterator": "error",
    "no-caller": "error",
    "no-extend-native": "error",
    "no-extra-bind": "error",
    "no-invalid-this": "error",
    "no-multi-spaces": "error",
    "no-multi-str": "error",
    "no-new-wrappers": "error",
    "no-throw-literal": "error",
    "no-with": "error",
    "no-unused-expressions": "error",
    "no-useless-call": "error",
    "no-useless-concat": "error",
    "no-void": "error",
    "prefer-promise-reject-errors": "error",
    "radix": "error",
    "wrap-iife": ["error", "any"],
    "yoda": "error",

    // Code style rules (handled by prettier, but keep some for logic)
    "array-bracket-spacing": "off",
    "comma-dangle": "off",
    "comma-spacing": "off",
    "computed-property-spacing": "off",
    "func-call-spacing": "off",
    "indent": "off", 
    "key-spacing": "off",
    "keyword-spacing": "off",
    "no-extra-parens": "off",
    "no-extra-semi": "off",
    "no-floating-decimal": "off",
    "no-mixed-spaces-and-tabs": "off",
    "no-multi-spaces": "off",
    "no-multiple-empty-lines": "off",
    "no-spaced-func": "off",
    "no-trailing-spaces": "off",
    "no-whitespace-before-property": "off",
    "object-curly-spacing": "off",
    "operator-linebreak": "off",
    "padded-blocks": "off",
    "quote-props": "off",
    "quotes": "off",
    "semi": "off",
    "semi-spacing": "off",
    "space-before-blocks": "off",
    "space-before-function-paren": "off",
    "space-in-parens": "off",
    "space-infix-ops": "off",
    "space-unary-ops": "off",

    // Unicorn rules customization
    "unicorn/prevent-abbreviations": "off",
    "unicorn/filename-case": "off",
    "unicorn/no-null": "off",
    "unicorn/prefer-module": "off",
    "unicorn/prefer-node-protocol": "off",
    "unicorn/no-array-reduce": "off",
    "unicorn/no-nested-ternary": "off",
    "unicorn/consistent-destructuring": "warn",
    "unicorn/prefer-spread": "error",
    "unicorn/prefer-ternary": "warn",

    // SonarJS rules
    "sonarjs/cognitive-complexity": ["error", 15],
    "sonarjs/max-switch-cases": ["error", 30],
    "sonarjs/no-duplicate-string": ["error", 5],
    "sonarjs/no-identical-functions": "error",

    // Promise rules
    "promise/always-return": "error",
    "promise/catch-or-return": "error",
    "promise/no-nesting": "warn",
    "promise/no-return-wrap": "error",
    "promise/param-names": "error",

    // Unused imports
    "unused-imports/no-unused-imports": "error",
    "unused-imports/no-unused-vars": [
      "warn",
      { 
        vars: "all", 
        varsIgnorePattern: "^_", 
        args: "after-used", 
        argsIgnorePattern: "^_" 
      }
    ],

    // Sort keys
    "sort-keys-fix/sort-keys-fix": "warn",
    "sort-destructure-keys/sort-destructure-keys": "error"
  },
  overrides: [
    {
      files: ["*.test.ts", "*.test.tsx", "*.spec.ts", "*.spec.tsx"],
      env: {
        jest: true
      },
      extends: ["plugin:jest/recommended", "plugin:jest/style"],
      rules: {
        "@typescript-eslint/no-explicit-any": "off",
        "@typescript-eslint/no-unsafe-any": "off",
        "@typescript-eslint/no-unsafe-assignment": "off",
        "@typescript-eslint/no-unsafe-call": "off",
        "@typescript-eslint/no-unsafe-member-access": "off",
        "@typescript-eslint/no-unsafe-return": "off",
        "sonarjs/no-duplicate-string": "off",
        "security/detect-object-injection": "off"
      }
    },
    {
      files: ["*.js", "*.jsx"],
      rules: {
        "@typescript-eslint/no-var-requires": "off",
        "@typescript-eslint/explicit-function-return-type": "off"
      }
    },
    {
      files: ["programs/**/*.ts", "programs/**/*.js"],
      env: {
        node: true,
        browser: false
      },
      rules: {
        "react/react-in-jsx-scope": "off",
        "react-hooks/rules-of-hooks": "off",
        "react-native/no-unused-styles": "off",
        "@typescript-eslint/no-unsafe-assignment": "warn",
        "@typescript-eslint/no-unsafe-member-access": "warn"
      }
    },
    {
      files: ["scripts/**/*.ts", "scripts/**/*.js"],
      env: {
        node: true,
        browser: false
      },
      rules: {
        "no-console": "off",
        "unicorn/no-process-exit": "off"
      }
    },
    {
      files: ["*.config.js", "*.config.ts", "*.rc.js"],
      env: {
        node: true
      },
      rules: {
        "@typescript-eslint/no-var-requires": "off",
        "import/no-default-export": "off"
      }
    }
  ],
  ignorePatterns: [
    "node_modules/",
    "dist/",
    "build/",
    "target/",
    "coverage/",
    ".next/",
    ".nuxt/",
    "*.min.js",
    "*.bundle.js",
    "public/",
    ".git/",
    ".vscode/",
    ".idea/",
    "*.log"
  ]
};
